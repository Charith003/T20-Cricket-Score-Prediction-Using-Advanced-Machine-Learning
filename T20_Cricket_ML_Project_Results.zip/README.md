# T20 Cricket Match Score Prediction

Regression and ensemble-learning project that predicts the `Predicted Score` column of a public T20 cricket dataset from match-progress and match-condition inputs.

> **Read this first.** The results below describe performance **on this dataset**. The way the target was generated has not been independently established, and some records are internally inconsistent (see [Model limitations](#model-limitations)). A high R² here is **not** evidence of real-world cricket forecasting ability.

## Project overview
A single Google Colab notebook (`T20_Cricket_Score_Prediction_Advanced.ipynb`) loads and audits the data, runs EDA, builds a leakage-safe scikit-learn pipeline, compares 11 regressors plus Voting and Stacking ensembles, tunes the strongest models, selects one using validation and cross-validation only, evaluates it **once** on an untouched test set, explains it, and exports it with an interactive predictor.

## Objectives
- Maximise genuine out-of-sample accuracy without data leakage (Match ID excluded, all preprocessing fitted on training data only).
- Compare many model families fairly on identical splits.
- Report honest, reproducible metrics and an empirical prediction interval.

## Dataset information
| Item | Value |
|---|---|
| Source | [Kaggle: zeeshier/t20-cricket-match-score-dataset](https://www.kaggle.com/datasets/zeeshier/t20-cricket-match-score-dataset) |
| File | `dataset/t20_cricket_match_score_prediction.csv` (included) |
| Size | 1,500 rows x 9 columns (verified) |
| Columns | Match ID, Overs Played, Wickets Lost, Run Rate, Home/Away, Opponent Strength, Pitch Condition, Weather, Predicted Score |
| Target | `Predicted Score` |
| Missing / duplicate rows | 0 / 0 (verified) |

Verified in the notebook: ranges are valid, and **435 of 1,500 rows (29.0%) have estimated current runs greater than the final target score**. These rows are flagged but kept.
Not established: how `Predicted Score` was generated.

### Dataset acquisition
1. **Included copy (default):** the CSV is in `dataset/`; the notebook finds it automatically.
2. **Kaggle:** download from the link above and place the file in `dataset/`, or set `USE_KAGGLE_DOWNLOAD = True` in the notebook (requires Kaggle access, e.g. `KAGGLE_USERNAME`/`KAGGLE_KEY`).
3. **Google Colab upload:** if no file is found in Colab, an upload prompt appears (file name must be `t20_cricket_match_score_prediction.csv`).
4. **Google Drive:** set `USE_GOOGLE_DRIVE = True` and `DRIVE_PATH`.

The loader validates the file name and the 9 required columns and prints a clear error if the data is unavailable. Routes 1 and the missing-file error message were tested; the Kaggle, Drive and upload routes need Colab/Kaggle access and were **not** exercised in the build environment.

## Technologies used
Python 3.12, NumPy, pandas, SciPy, scikit-learn, XGBoost, LightGBM, CatBoost, Optuna, SHAP, Matplotlib, Seaborn, Joblib, ipywidgets (exact versions in `requirements.txt`).

## Machine learning algorithms
- **Linear:** Linear, Ridge, Lasso
- **Trees:** Decision Tree, Random Forest, Extra Trees
- **Boosting:** Gradient Boosting, HistGradientBoosting, XGBoost, LightGBM, CatBoost
- **Ensembles:** Voting Regressor (CV-chosen inverse-RMSE weights) and Stacking Regressor (Ridge meta-model, out-of-fold base predictions)
- A mean-predicting dummy model is included as a baseline.

## Feature engineering
Implemented in `t20_features.py` and used identically in training and prediction. A cross-validated ablation compared `raw`, `basic` and `full` (with interactions) feature sets; **`basic`** was selected.
- `current_est_runs` = Overs Played x Run Rate. **This is only an approximation of the current score** (it assumes a constant run rate and is not guaranteed to equal the exact runs scored).
- `wickets_remaining`, `overs_remaining`, `remaining_innings_pct`, `wicket_pressure`
- `scoring_phase` (powerplay / middle / death) and `run_rate_category`

No feature uses the target.

## Model optimization
Ridge/Lasso: GridSearchCV. Random Forest, HistGradientBoosting, XGBoost, CatBoost: RandomizedSearchCV. LightGBM: Optuna (20 trials). All tuning used 5-fold CV on the training split only.

## Final model performance
Split: 1,049 train / 226 validation / 225 test (random, seed 42). Final model: **Stacking Regressor** (CatBoost, LightGBM, XGBoost and HistGradientBoosting base learners), refit on train + validation.

| Final test set (evaluated once) | Result |
|---|---|
| MAE | 1.35 runs |
| RMSE | 1.90 runs |
| R² | 0.999 |
| Within ±5 runs (custom tolerance metric) | 96.4% |
| Within ±10 runs | 100% |
| 5-fold CV RMSE (train + validation) | 2.03 ± 0.14 |
| 90% empirical prediction interval | ±3.0 runs; observed test coverage 89.8% |
| Mean-predictor baseline RMSE | 70.9 |

The ±N-run figures are a custom tolerance-based metric, not classification accuracy. **These are dataset-specific experimental results, not guarantees and not real-world cricket forecasting performance.**

## Prediction system
```python
import sys, joblib, pandas as pd
sys.path.insert(0, ".")                      # folder containing t20_features.py
pipe = joblib.load("models/t20_prediction_pipeline.pkl")
row = pd.DataFrame([{"Overs Played": 10, "Wickets Lost": 3, "Run Rate": 8.0, "Home/Away": "Home",
                     "Opponent Strength": 5, "Pitch Condition": "Balanced", "Weather": "Sunny"}])
print(pipe.predict(row))                     # about 100.5 runs
```
The notebook also provides `predict_t20_score(...)` with input validation and a 90% empirical band, plus an ipywidgets interface (text-input fallback if widgets are unavailable).

## Installation
```bash
git clone <your-repository-url> T20-Cricket-Score-Prediction
cd T20-Cricket-Score-Prediction
python3.12 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt jupyter
jupyter notebook T20_Cricket_Score_Prediction_Advanced.ipynb
```
Or with conda: `conda env create -f environment.yml` (not tested in the build environment; `requirements.txt` was tested).

## Google Colab execution
1. Upload the project folder to Colab (or Google Drive / GitHub clone) so the notebook sits next to `dataset/`.
2. Open the notebook and choose **Runtime -> Run all** (about 5 minutes on one CPU).
3. If the dataset is not found, upload the CSV when prompted.
4. Section 1A compares Colab's library versions with the training versions. Colab's default scikit-learn will likely differ, so loading the **pre-saved** pickles may warn or fail there; running the notebook regenerates all artifacts with your session's versions. To use the saved pickles as-is, install the pinned versions (`pip install -r requirements.txt`) and restart the runtime.

## Project structure
```
T20-Cricket-Score-Prediction/
├── T20_Cricket_Score_Prediction_Advanced.ipynb   # full executed notebook
├── README.md
├── requirements.txt
├── environment.yml
├── runtime_versions.json
├── t20_features.py            # feature-engineering module; required to unpickle the models
├── dataset/
│   └── t20_cricket_match_score_prediction.csv
├── models/
│   ├── best_t20_model.pkl                 # fitted Stacking Regressor only
│   ├── t20_prediction_pipeline.pkl        # raw input DataFrame -> score
│   └── t20_preprocessing_pipeline.pkl     # fitted feature engineering + encoding
├── results/
│   ├── model_evaluation_results.csv
│   ├── actual_vs_predicted.csv
│   ├── feature_importance.csv
│   ├── model_metadata.json
│   └── final_report.txt
└── visualizations/                        # 14 figures
```

## Model limitations
- **Target provenance is unverified.** The generation method of `Predicted Score` has not been independently established; the original dataset documentation was not available when this was built. The data patterns (a simple linear formula explains R² ≈ 0.97, boosting explains almost everything) are *consistent with* a formula-generated target, but that is a hypothesis, not a confirmed fact.
- **Internal inconsistency.** 29.0% of rows have estimated current runs above the final score, which raises cricket-score consistency questions. Rows were not removed.
- **High R² is not real-world capability.** The model may have learned the rule that produced the target.
- **No chronology:** no dates or match IDs usable for time-based validation; random split only.
- **Interval** is a single average band (errors may vary with score); feature importance is not causation.
- **External validation** on genuine historical T20 data is required before any real-world forecasting claim.

## Reproducibility
- Fixed seed (`SEED = 42`); exact versions in `requirements.txt` and `runtime_versions.json`.
- Python, NumPy, pandas and scikit-learn versions were recorded at training time; the remaining versions were read from the same unchanged environment.
- Audit performed: the notebook was rerun end to end and reproduced every reported metric and all 225 test predictions exactly. The saved pipeline loads in a fresh process and in a clean virtual environment built from `requirements.txt` (predictions match the saved CSV to its 2-decimal rounding).
- Notebook Section 19A re-checks loading, feature names, prediction reproducibility and metadata consistency on every run.

## Future improvements
- Validate on genuine historical T20 data with time-based splits.
- Confirm the dataset's generation method from its documentation or author.
- Add richer context (venue, batter/bowler quality, required run rate) and heteroscedastic or conformal intervals.
- Package the predictor as an API or app.
